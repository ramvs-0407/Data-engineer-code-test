import org.apache.spark.sql.types.{ArrayType, MetadataBuilder, StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object Assignment {
  def getFileExtension(filePath: String): String = {

    val reg_ex = """.*\.(\w+)""".r

    filePath match {
      case reg_ex(ext) =>  s"$ext"
      case _ =>  ""
    }
  }

  def readJSONFile(filePath: String, spark: SparkSession): DataFrame = {
    val df = spark.read.option("multiline","true").json(filePath)
    df
  }

  def readXMLFile(filePath: String, spark: SparkSession): DataFrame = {
    val df = spark.read.format("com.databricks.spark.xml").option("rowTag", "root").load(filePath)
    df
  }

  def saveFileToTargetFolder(saveFilePath: String, resultDataframe: DataFrame): Unit = {
    resultDataframe.write.mode("overwrite").parquet(saveFilePath)
  }

  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder().master("local[*]").appName("Assignment").getOrCreate()

    val trailerFileList = List("trailer_2020-07-15T083049.345Z.xml", "trailer_2020-07-16T092142.345Z.xml", "trailer_2020-07-19T062021.325Z.xml", "trailer_2020-07-20T021011.125Z.xml", "trailer_2020-07-21T011412.315Z.xml")

    val transportFileList = List("transport_2020-07-19T062021.325Z.json", "transport_2020-07-21T011412.315Z.json")

    val readFolderPath = "C:\\Users\\cneto\\Downloads\\RUI\\"

    val writeFolderPath = "C:\\Users\\cneto\\Downloads\\RUI\\"


    transportFileList.foreach(file => {
      val df = readJSONFile(readFolderPath + file, spark)
      val timestamp = df.select("CreatedAt").collect()(0).toString().replaceAll("[\\[\\]]", "")

      val fileFormat = getFileExtension(readFolderPath + file)

      //Adding the metadata
      val metadata = new MetadataBuilder().putString("meta_extension", s"$fileFormat").putString("meta_insert_timestamp", s"$timestamp").build

      //Creating the custom schema for reading the JSON file
      val customTransportSchema = StructType(Seq(
        StructField("CreatedAt", StringType, nullable = true, metadata),
        StructField("EndAddress", StructType(Seq(
          StructField("City", StringType, nullable = true, metadata),
          StructField("Country", StringType, nullable = true, metadata),
          StructField("CountryCode", StringType, nullable = true, metadata),
          StructField("GeoPoint", StructType(Seq(
            StructField("Latitude", StringType, nullable = true, metadata),
            StructField("Longitude", StringType, nullable = true, metadata),
          )), nullable = true),
          StructField("Zip", StringType, nullable = true, metadata)
        )), nullable = true),
        StructField("IMEIs", ArrayType(StringType, containsNull = true), nullable = true, metadata),
        StructField("LastModified", StringType, nullable = true, metadata),
        StructField("StartAddress", StructType(Seq(
          StructField("City", StringType, nullable = true, metadata),
          StructField("Country", StringType, nullable = true, metadata),
          StructField("CountryCode", StringType, nullable =  true, metadata),
          StructField("GeoPoint", StructType(Seq(
            StructField("Latitude", StringType, nullable = true, metadata),
            StructField("Longitude", StringType, nullable = true, metadata),
          )),nullable =  true, metadata),
          StructField("Zip", StringType, nullable = true, metadata)
        )), nullable = true, metadata),
        StructField("TrailerId", StringType, nullable = true, metadata),
        StructField("TransportType", StringType, nullable = true, metadata),
        StructField("id", StringType, nullable = true, metadata)
      ))

      val finalDF = spark.read.schema(customTransportSchema).option("multiline", "true").json(readFolderPath + file)

      saveFileToTargetFolder(writeFolderPath +"processed\\" + file, finalDF)
    })

    trailerFileList.foreach(file => {
      val df = readXMLFile(readFolderPath + file, spark)

      val timestamp = df.select("CreatedAt").collect()(0).toString().replaceAll("[\\[\\]]", "")

      val fileFormat = getFileExtension(readFolderPath + file)

      //Adding the metadata
      val metadata = new MetadataBuilder().putString("meta_extension", s"$fileFormat").putString("meta_insert_timestamp", s"$timestamp").build

      //Creating the custom Schema for reading the XML File
      val customTrailerSchema = StructType(Seq(
        StructField("createdAt", StringType, nullable = true, metadata),
        StructField("geoMode", StringType, nullable = true, metadata),
        StructField("id", StringType, nullable = true, metadata),
        StructField("lastModified", StringType, nullable = true, metadata),
        StructField("lastReading", StringType, nullable = true, metadata),
        StructField("latitude", StringType, nullable = true, metadata),
        StructField("licensePlate", StringType, nullable = true, metadata),
        StructField("longitude", StringType, nullable = true, metadata),
        StructField("odometer", StringType, nullable = true, metadata),
        StructField("speed", StringType, nullable = true, metadata),
      ))

      val finalDF = spark.read.format("com.databricks.spark.xml").schema(customTrailerSchema).option("rowTag", "root").load(readFolderPath + file)

      saveFileToTargetFolder(writeFolderPath +"processed\\" + file, finalDF)
    })

  }
}
