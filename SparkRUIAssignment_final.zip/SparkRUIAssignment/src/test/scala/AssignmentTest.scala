import org.scalatest.funsuite.AnyFunSuite
import java.nio.file.{Files, Paths}
import org.apache.spark.sql.{DataFrame, SparkSession}


class AssignmentTest extends AnyFunSuite {
  val spark: SparkSession = SparkSession.builder().master("local[*]").appName("ScalaTest").getOrCreate()
  import spark.implicits._

  val jsonDF: DataFrame = Seq(
    (8)
  ).toDF("stringNumber")


  test("Assignment.getFileExtension") {
    assert(Assignment.getFileExtension("C:\\Users\\cneto\\Downloads\\RUI\\trailer_2020-07-15T083049.345Z.xml") === "xml")
    assert(Assignment.getFileExtension("C:\\Users\\cneto\\Downloads\\RUI\\transport_2020-07-19T062021.325Z.json") === "json")
  }

  test("Assignment.saveFileToTargetFolder") {
    Files.exists(Paths.get("C:\\Users\\cneto\\Downloads\\RUI\\processed"))
  }

  test("Assignment.readJSONFile") {
    assert(Assignment.readJSONFile("C:\\Users\\cneto\\Downloads\\RUI\\jsonTest.json", spark).except(jsonDF).union(jsonDF.except(Assignment.readJSONFile("C:\\Users\\Amit\\Downloads\\Fiverr\\RUI\\jsonTest.json", spark))).count() === 0)
  }

  test("Assignment.readXMLFile") {
    assert(Assignment.readXMLFile("C:\\Users\\cneto\\Downloads\\RUI\\xmlTest.xml", spark).except(jsonDF).union(jsonDF.except(Assignment.readXMLFile("C:\\Users\\Amit\\Downloads\\Fiverr\\RUI\\xmlTest.xml", spark))).count() === 0)
  }
}
